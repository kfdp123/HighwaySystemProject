var ctx_line ;


  var config = {
      type: 'line',
      data: {
          labels: [],
          datasets: []
      },
      options: {

          legend:{
              display:false,
          },
          responsive: true,
          title:{
              display:true,
              fontSize:20,
              fontColor:'#5bc153',
              text:'最大遮蔽角密位分析图'
          },
          tooltips: {
              mode: 'index',
              intersect: false,
          },
          hover: {
              mode: 'nearest',
              intersect: true
          },
          scales: {
              xAxes: [{
                  display: true,
                  scaleLabel: {
                      display: true,
                      fontSize:17,
                      fontColor:'#5bc153',
                      labelString: '密       位'
                  }
              }],
              yAxes: [{
                  display: true,
                  scaleLabel: {
                      display: true,
                      fontSize:17,
                      fontColor:'#5bc153',
                      labelString: '遮蔽角度数（º）'
                  }
              }]
          }
      }
  };
   var newDataset = {
      label: "遮蔽角度数",
      fill: false,
      backgroundColor: window.chartColors.blue,
      borderColor: window.chartColors.blue,
      pointRadius:0,
      fill:true,
      lineTension:0,
      data: []
    };
  /*雷达*/
  var chartColors = window.chartColors;
  var color = Chart.helpers.color;
  var config2 = {
      data: {
          datasets: [],
          labels: []
      },
      options: {
          defaultFontColor:'',
          startAngle:0,
          responsive: true,
          legend: {
              display:false,
              position: 'right',
          },
          title: {
              display: true,
              fontSize:20,
              fontColor:'#5bc153',
              text: '最大遮蔽角雷达图'
          },
          scale: {
              gridLines:{display:true,
                  zeroLineColor:"rgba(0, 0, 0, 0.25)",
              },
              ticks: {
                  display: true,
                  beginAtZero: true
              },
              reverse: false
          },
          animation: {
              animateRotate: false,
              animateScale: true
          }
      }};
     var newDataset2={
				  data: [],
				  backgroundColor: [],
				  borderWidth:[],
				  label: 'My dataset',
				  xAxisID: "x-axis-1",
				  yAxisID: "y-axis-1",
			  }
			  
     /*高程值剖面  */
	 
   var config3 = {
        type: 'line',
        data: {
            labels: [],
            datasets: []
        },
        options: {
            legend:{
                display:true,
            },
            responsive: true,
            title:{
                display:true,
                fontSize:20,
                fontColor:'#5bc153',
                text:'两点之间剖面高程值'
            },
            tooltips: {
                mode: 'index',
                intersect: false,
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        fontSize:17,
                        fontColor:'#5bc153',
                        labelString: '栅格坐标'
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: true,
                        fontSize:17,
                        fontColor:'#5bc153',
                        labelString: '高程（m）'
                    }
                }]
            }
        }
    };
	    	 var newDataset3 = {
                label: "高程",
                fill: false,
                backgroundColor: window.chartColors.blue,
                borderColor: window.chartColors.blue,
                data: []
            };

    
   
      var  begin_state=0;
    function radar_plline_draw(){
	      
	    if(begin_state==3){
	     window.myPolarArea.destroy();
		}
		  if(begin_state==2){
	     window.myLineLine.destroy();
		}
	     ctx_line = document.getElementById("canvas-line").getContext("2d");
		
         myLine = new Chart(ctx_line, config);
	    var drawpicture= document.getElementById('drawpicture')
         drawpicture.style.display='';
	   
	   //$("#radar_all").hide();
	  
      $.getJSON("scripts/radar/loaddata.json",function(data) {
		  config.data.labels=[];
          newDataset.data=[];
          for (var i = 0; i < data.length; i++) {
              switch (i) {
                  case 0:
                      config.data.labels.push(0);
                      break;
                  case 90:
                      config.data.labels.push(1500);
                      break;
                  case 180:
                      config.data.labels.push(3000);
                      break;
                  case 270:
                      config.data.labels.push(4500);
                      break;
                  case 359:
                      config.data.labels.push(6000);
                      break;
                  default:
                      config.data.labels.push('');
                      break;
              }
              newDataset.data.push(data[i].angle);
              
          }
		 
          config.data.datasets.push(newDataset);
           window.myLine.update();
		  
        })
          begin_state=1; 
		
	}
	
      
	  
      function radar_polar_draw(){
		  if(begin_state==1){
		  window.myLine.destroy();
		  }
		   if(begin_state==2){
	     window.myLineLine.destroy();
		}
		 ctx_line= document.getElementById("canvas-line").getContext("2d");
		
		   window.myPolarArea = Chart.PolarArea(ctx_line, config2);
		   
             drawpicture.style.display='';
			  
			   $.getJSON("scripts/radar/loaddata.json",function(data) {
				    config2.data.labels=[];
                  newDataset2.data=[]; 
				   for(var j=0;j<data.length;j++){
              config2.data.labels.push("遮蔽角度数");
              newDataset2.data.push(data[359-j].angle);
              newDataset2.backgroundColor.push(color(chartColors.blue).alpha(0.5).rgbString());
              newDataset2.borderWidth.push(0);
               }
      		    config2.data.datasets.push(newDataset2);
                window.myPolarArea.update();
			   })
			   begin_state=3; 
		     }
	   
	    var label_array=[25107,25108,25109,25110,25111, 25112,
         25113,25114,25115,25116,25117,25118,25119,25120,25121,25122,25123,25124,25125,25126,25127,25128]
     var data_array=[8.0,8.0,6.0,5.0,7.0,6.0,5.0,3.0,5.0,2.0,2.0,2.0,1.0,-3.0,-3.0,-3.0,-3.0,-3.0,-3.0,2.0,4.0,3.0]
         function twopoint_attitude2(){
			 if(begin_state==1){
				 window.myLine.destroy(); 
			 }
			 if(begin_state==3){
	     window.myPolarArea.destroy();
		}
		
		var ctx_line = document.getElementById("canvas-line").getContext("2d");
         myLineLine = new Chart(ctx_line,config3);
		 
		  drawpicture.style.display='';
		  config3.data.labels=[];
          newDataset3.data=[];
		   var flag=0;
      
        // 横坐标刻度
        if (flag == 0) {
            for (var m = 0; m < label_array.length; m++) {
                config3.data.labels.push(label_array[m]);
            }

        

            for (var j = 0; j < data_array.length; j++) {
                newDataset3.data.push(data_array[j]);
            }
            config3.data.datasets.push(newDataset3);
            window.myLineLine.update();
            flag = 1;
        }
		   begin_state=2; 
      }
	   function radar_line_cancel(){
		   drawpicture.style.display="none";
		   $("#radar_all").hide();
	  }
 
     


